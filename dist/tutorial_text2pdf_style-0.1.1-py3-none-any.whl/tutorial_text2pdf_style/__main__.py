from . import converter_script

if __name__ == "__main__":
    converter_script.main()